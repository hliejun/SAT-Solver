import static org.junit.Assert.*;
import org.junit.Test;

public class UtilitiesTest {

    @Test
    public void testTokenizeAndRemoveZero() {
        fail("Not yet implemented");
    }

    @Test
    public void testRemoveSignsAndSpaces() {
        fail("Not yet implemented");
    }

    @Test
    public void testIsComment() {
        fail("Not yet implemented");
    }

    @Test
    public void testIsPositive() {
        fail("Not yet implemented");
    }

    @Test
    public void testImplode() {
        fail("Not yet implemented");
    }

}